package kosa.mission.interface00;

public interface Speakable {
	public String speak();
}
