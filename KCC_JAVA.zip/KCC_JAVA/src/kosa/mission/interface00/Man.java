package kosa.mission.interface00;

public class Man {
	private String name;
	
	public Man() {
		
	}
	
	
	public Man(String name) {
		this.name = name;
	}


	public String getName() {
		return name;
	}
}
