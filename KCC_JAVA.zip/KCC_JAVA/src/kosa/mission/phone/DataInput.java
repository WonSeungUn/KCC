package kosa.mission.phone;

import java.util.Scanner;

public class DataInput {
	// Scanner => static 생성
	static Scanner sc = new Scanner(System.in);
	
}
