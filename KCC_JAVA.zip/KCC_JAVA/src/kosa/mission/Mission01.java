package kosa.mission;

public class Mission01 {

	public static void main(String[] args) {
		// 이름, 나이, 주소를 변수에 각각 담아서 콘솔에 출력해보기
		// 이름 : 홍길동
		// 나이 : 24
		// 주소 : 서울시 종로구 명륜동
		
		String name = "홍길동";
		
		int age = 24;
		
		String address = "서울시 종로구 명륜동";
		
		System.out.println("이름 : " + name);
		System.out.println("나이 : " + age);
		System.out.println("주소 : " + address);
		

	}

}
