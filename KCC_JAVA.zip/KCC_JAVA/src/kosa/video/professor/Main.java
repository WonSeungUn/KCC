package kosa.video.professor;

public class Main {
	public static void main(String[] args) {
		Video v1= new Video("1", "트랜스포머3", "서봉수");
		Video v2= new Video("2", "쿵푸팬더4", "지성민");
		
		GeneralMember gm = new GeneralMember("aaa", "홍길동", "서울");
		
		gm.rental(v1);
		gm.rental(v2);
		gm.show();
	}
}
