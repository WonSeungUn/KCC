package kosa.oop3;

public abstract class Role {
	public abstract void doing();
}
