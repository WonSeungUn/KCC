package kosa.oop3;

public class Work extends Role {

	@Override
	public void doing() {
		System.out.println("노동자의 할일은 일을 하는 것입니다.");
	}

}
