package kosa.oop3;

public class Student extends Role {

	@Override
	public void doing() {
		System.out.println("학생의 할일은 공부입니다.");
	}

}
