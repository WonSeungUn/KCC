package kosa.basic;

public class HelloWorld {

	public static void hello() {
		System.out.println("안녕!!!");
	}

	public static void main(String[] args) {
		System.out.println("Hello KCC!!!!!");
		System.out.println("Hello KOSA!!!!!");

		hello();
	}  // end main

} // end Class
