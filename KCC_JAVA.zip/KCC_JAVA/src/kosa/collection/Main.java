package kosa.collection;

public class Main {
	public static void main(String[] args) {
		String a = "2022-02-03";
		String b = "2022/02/02";
		System.out.println(a.compareTo(b));
	}
}
