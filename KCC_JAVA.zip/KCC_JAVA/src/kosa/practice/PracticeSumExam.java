package kosa.practice;

public class PracticeSumExam extends Thread {
	private int a;
	private int b;
	private int total;

	public PracticeSumExam() {
	}

	public void run() {
		int sum = 0;
		for (int i = a; i < b; i++) {
			 sum += a++;
			 total = sum;
			try {
				Thread.sleep(1000);
				System.out.println("=========");
				System.out.println(total);
				System.out.println("=========");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public PracticeSumExam(int a, int b) {
		super();
		this.a = a;
		this.b = b;
	}

	public int getTotal() {
		return total;
	}

}
