package kosa.practice;

public class PracticeAverageExam extends Thread {
	private int a;
	private int b;
	private double avg;
	
	public PracticeAverageExam() {
	
	}

	public PracticeAverageExam(int a, int b) {
		this.a = a;
		this.b = b;
	}
	
	
	public void run() {
		int sum =0;
		for(int i =a ; i<b ; i++) {
			sum += a++;
			avg = sum/i;
			try {
				Thread.sleep(1000);
				System.out.println("=========");
				System.out.println(avg);
				System.out.println("=========");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public double getAvg() {
		return avg;
	}

	
	
}
