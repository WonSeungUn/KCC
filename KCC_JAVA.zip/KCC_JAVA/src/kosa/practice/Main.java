package kosa.practice;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Main {

	public static void main(String[] args) {
		Thread thread = new PracticeSumExam(1,10);
		Thread thread2 = new PracticeAverageExam(1,10);
		
//		thread.start();
//		thread2.start();
		
		DateTimeFormatter date = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        String secondNum = LocalDate.now().format(date).substring(2,4);
        System.out.println(secondNum);
		
		
	}

}
