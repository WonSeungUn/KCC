package kosa.function;

import java.util.LinkedHashSet;

public class DeleteDuplication {
    public static void main(String[] args) {
        String a = "직원, 고유코드, 직원, 성명, 주민등록번호, 주소, 전화번호, 저장, 직원, 부서, 입사날짜, 월급, 직급, 직원, 직급, 관리 놀이기구, 놀이기구, 고유코드, 놀이기구, 이름, 생성날짜, 특징, 저장, 놀이기구, 이용, 사용자, 제한, 사용자, 키, 관리, 직원, 고유코드, 놀이기구 생성날짜, 안전검사, 시행, 안전검사, 안전검사 고유코드, 안전검사, 설명, 시행날짜, 놀이 기구, 직원, 정보, 저장, 직원, 놀이기구, 안전검사, 시행, 부서, 고유코드, 이름, 위치, 정보, 부서 종류, 티켓 관리부서, 놀이기구 관리 부서, 안전관리부서, 존재, 티켓, 티켓코드, 이름, 가격, 티켓, 자유이용권, BIG3, 주간, 야간, 놀이기구 티켓, 존재, 연령, 청소년, 어린이, 어른, 정보, 티켓이름, 티켓코드, 티켓 이용날짜, 발행일, 하루, 티켓판매, 판매 고유코드, 결제날짜, 결제방법, 결제수량, 저장, 티켓, 직원, 판매, 정보";

        // 문자열을 쉼표로 분리
        String[] words = a.split(",\\s*");

        // LinkedHashSet을 사용하여 중복을 제거하고 순서를 유지
        LinkedHashSet<String> uniqueWords = new LinkedHashSet<>();

        for (String word : words) {
            uniqueWords.add(word);
        }

        // 결과 출력
        for (String word : uniqueWords) {
            System.out.print(word + ", ");
        }
    }
}

