package kosa.oop2;

public abstract class Dao { //추상클래스 
	public abstract void insert(); // 추상메서드
}
