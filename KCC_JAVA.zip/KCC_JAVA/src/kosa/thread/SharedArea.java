package kosa.thread;


public class SharedArea {
	Account account1;
	Account account2;
}
