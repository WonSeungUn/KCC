package kosa.oop4;

public interface MyNumber {
	int getMax(int num1, int num2);
}
