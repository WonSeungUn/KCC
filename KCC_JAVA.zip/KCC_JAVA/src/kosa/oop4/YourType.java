package kosa.oop4;

public interface YourType {
	public void talk(String message);
}
