package kosa.oop4;

public interface MyType {
	public void hello();
}
